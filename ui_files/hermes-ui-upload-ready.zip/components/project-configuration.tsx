"use client"

import type React from "react"

import { useHermes } from "@/context/hermes-context"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Upload } from "lucide-react"

export default function ProjectConfiguration() {
  const { projectConfig, updateProjectConfig } = useHermes()

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>, key: keyof typeof projectConfig) => {
    if (e.target.files && e.target.files[0]) {
      updateProjectConfig(key, e.target.files[0])
    }
  }

  const handleDownload = (templateName: string) => {
    // In a real app, this would download the actual template
    alert(`Downloading ${templateName} template`)
  }

  return (
    <div className="grid grid-cols-1 gap-6">
      {/* Project Name */}
      <div className="space-y-2">
        <Label htmlFor="project-name">Project name:</Label>
        <Input
          id="project-name"
          value={projectConfig.name}
          onChange={(e) => updateProjectConfig("name", e.target.value)}
          placeholder="Enter project name"
        />
      </div>

      {/* Hermes Rules */}
      <div className="space-y-2">
        <Label>Hermes rules</Label>
        <div className="space-y-2">
          <Button variant="outline" className="w-full" onClick={() => document.getElementById("hermes-rules")?.click()}>
            <Upload className="mr-2 h-4 w-4" />
            {projectConfig.hermesRules ? projectConfig.hermesRules.name : "Upload"}
          </Button>
          <input
            id="hermes-rules"
            type="file"
            className="hidden"
            onChange={(e) => handleFileChange(e, "hermesRules")}
          />
          <Button variant="link" className="h-auto p-0 text-sm" onClick={() => handleDownload("Hermes Rules")}>
            Download template
          </Button>
        </div>
      </div>
    </div>
  )
}

