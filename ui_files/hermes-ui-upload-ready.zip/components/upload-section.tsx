"use client"

import type React from "react"

import { useHermes } from "@/context/hermes-context"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Upload } from "lucide-react"

export function UploadSection() {
  const { projectConfig, updateProjectConfig } = useHermes()

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>, key: keyof typeof projectConfig) => {
    if (e.target.files && e.target.files[0]) {
      updateProjectConfig(key, e.target.files[0])
    }
  }

  const handleDownload = (templateName: string) => {
    // In a real app, this would download the actual template
    alert(`Downloading ${templateName} template`)
  }

  return (
    <div className="border border-gray-200 rounded-lg p-6">
      <h2 className="text-xl font-semibold mb-4">Upload Section</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* UI Files */}
        <div className="space-y-2">
          <Label>UI files</Label>
          <Button variant="outline" className="w-full" onClick={() => document.getElementById("ui-files")?.click()}>
            <Upload className="mr-2 h-4 w-4" />
            Upload .zip
          </Button>
          <input
            id="ui-files"
            type="file"
            accept=".zip"
            className="hidden"
            onChange={(e) => handleFileChange(e, "uiFiles")}
          />
        </div>

        {/* Features Overview */}
        <div className="space-y-2">
          <Label>Features overview</Label>
          <Button
            variant="outline"
            className="w-full"
            onClick={() => document.getElementById("features-overview")?.click()}
          >
            <Upload className="mr-2 h-4 w-4" />
            Upload
          </Button>
          <input
            id="features-overview"
            type="file"
            className="hidden"
            onChange={(e) => handleFileChange(e, "featuresOverview")}
          />
          <Button variant="link" className="h-auto p-0 text-sm" onClick={() => handleDownload("Features Overview")}>
            Download template
          </Button>
        </div>

        {/* Project Manifest */}
        <div className="space-y-2">
          <Label>Project manifest</Label>
          <Button
            variant="outline"
            className="w-full"
            onClick={() => document.getElementById("project-manifest")?.click()}
          >
            <Upload className="mr-2 h-4 w-4" />
            Upload
          </Button>
          <input
            id="project-manifest"
            type="file"
            className="hidden"
            onChange={(e) => handleFileChange(e, "projectManifest")}
          />
          <Button variant="link" className="h-auto p-0 text-sm" onClick={() => handleDownload("Project Manifest")}>
            Download template
          </Button>
        </div>

        {/* Module Structure */}
        <div className="space-y-2">
          <Label>Module structure</Label>
          <Button
            variant="outline"
            className="w-full"
            onClick={() => document.getElementById("module-structure")?.click()}
          >
            <Upload className="mr-2 h-4 w-4" />
            Upload
          </Button>
          <input
            id="module-structure"
            type="file"
            className="hidden"
            onChange={(e) => handleFileChange(e, "moduleStructure")}
          />
          <Button variant="link" className="h-auto p-0 text-sm" onClick={() => handleDownload("Module Structure")}>
            Download template
          </Button>
        </div>

        {/* Structure Map */}
        <div className="space-y-2">
          <Label>Structure map</Label>
          <Button
            variant="outline"
            className="w-full"
            onClick={() => document.getElementById("structure-map")?.click()}
          >
            <Upload className="mr-2 h-4 w-4" />
            Upload
          </Button>
          <input
            id="structure-map"
            type="file"
            className="hidden"
            onChange={(e) => handleFileChange(e, "structureMap")}
          />
          <Button variant="link" className="h-auto p-0 text-sm" onClick={() => handleDownload("Structure Map")}>
            Download template
          </Button>
        </div>
      </div>
    </div>
  )
}

