"use client"

import type React from "react"

import { useHermes } from "@/context/hermes-context"
import { Card, CardContent } from "@/components/ui/card"
import { Textarea } from "@/components/ui/textarea"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"

export default function TaskSubmissionArea() {
  const { currentTask, updateTask, submitTask, isLoading } = useHermes()

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    submitTask()
  }

  return (
    <Card className="border border-gray-200">
      <CardContent className="p-6">
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="prompt">Task prompt</Label>
              <Textarea
                id="prompt"
                placeholder="Describe the task for Hermes to complete..."
                rows={8}
                value={currentTask.prompt}
                onChange={(e) => updateTask("prompt", e.target.value)}
                required
                className="resize-none"
              />
            </div>

            <div className="flex justify-end">
              <Button type="submit" className="w-full md:w-auto" disabled={isLoading || !currentTask.prompt}>
                {isLoading ? "Processing..." : "Send to Hermes"}
              </Button>
            </div>
          </div>
        </form>
      </CardContent>
    </Card>
  )
}

