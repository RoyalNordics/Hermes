"use client"

import { useHermes } from "@/context/hermes-context"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Copy, Download } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

export default function AgentResponseViewer() {
  const { agentResponse, isLoading } = useHermes()
  const { toast } = useToast()

  const copyToClipboard = () => {
    if (!agentResponse) return

    navigator.clipboard.writeText(agentResponse.content)
    toast({
      title: "Copied to clipboard",
      description: "The response has been copied to your clipboard.",
    })
  }

  const downloadResponse = () => {
    if (!agentResponse) return

    const blob = new Blob([agentResponse.content], { type: "text/plain" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `hermes-response-${new Date().toISOString().slice(0, 10)}.txt`
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
  }

  return (
    <Card className="h-full">
      <CardHeader className="flex flex-row items-center justify-between">
        <div>
          <CardTitle>Agent Response</CardTitle>
          <CardDescription>Hermes' solution to the submitted task</CardDescription>
        </div>
        {agentResponse && (
          <div className="flex gap-2">
            <Button variant="outline" size="icon" onClick={copyToClipboard}>
              <Copy className="h-4 w-4" />
              <span className="sr-only">Copy response</span>
            </Button>
            <Button variant="outline" size="icon" onClick={downloadResponse}>
              <Download className="h-4 w-4" />
              <span className="sr-only">Download response</span>
            </Button>
          </div>
        )}
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="flex items-center justify-center h-[400px]">
            <div className="animate-pulse text-center">
              <div className="h-4 bg-gray-200 rounded w-3/4 mx-auto mb-2"></div>
              <div className="h-4 bg-gray-200 rounded w-1/2 mx-auto"></div>
              <p className="mt-4 text-sm text-muted-foreground">Hermes is thinking...</p>
            </div>
          </div>
        ) : agentResponse ? (
          <div className="prose prose-sm max-w-none">
            <pre className="whitespace-pre-wrap bg-gray-50 p-4 rounded-md overflow-auto max-h-[400px]">
              {agentResponse.content}
            </pre>
          </div>
        ) : (
          <div className="flex items-center justify-center h-[400px] text-center text-muted-foreground">
            <div>
              <p>No response yet</p>
              <p className="text-sm">Submit a task to see Hermes' response</p>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  )
}

