"use client"

import { useHermes } from "@/context/hermes-context"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"

export default function SelfEvaluationPanel() {
  const { selfEvaluation, isLoading } = useHermes()

  return (
    <Card className="h-full">
      <CardHeader>
        <CardTitle>Self-Evaluation</CardTitle>
        <CardDescription>Hermes' assessment of its own performance</CardDescription>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="space-y-4">
            <div className="animate-pulse space-y-2">
              <div className="h-4 bg-gray-200 rounded w-1/4"></div>
              <div className="h-6 bg-gray-200 rounded w-full"></div>
            </div>
            <div className="animate-pulse space-y-2">
              <div className="h-4 bg-gray-200 rounded w-1/4"></div>
              <div className="h-6 bg-gray-200 rounded w-full"></div>
            </div>
            <div className="animate-pulse space-y-2">
              <div className="h-4 bg-gray-200 rounded w-1/4"></div>
              <div className="h-6 bg-gray-200 rounded w-3/4"></div>
            </div>
          </div>
        ) : selfEvaluation ? (
          <div className="space-y-6">
            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <h3 className="text-sm font-medium">Task Difficulty</h3>
                <span className="text-sm">{selfEvaluation.difficulty}/10</span>
              </div>
              <Progress value={selfEvaluation.difficulty * 10} className="h-2" />
            </div>

            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <h3 className="text-sm font-medium">Confidence Level</h3>
                <span className="text-sm">{selfEvaluation.confidence}/10</span>
              </div>
              <Progress value={selfEvaluation.confidence * 10} className="h-2" />
            </div>

            <div className="space-y-2">
              <h3 className="text-sm font-medium">Missing Knowledge Areas</h3>
              <div className="flex flex-wrap gap-2">
                {selfEvaluation.missingKnowledge.map((item, index) => (
                  <Badge key={index} variant="outline" className="bg-red-50">
                    {item}
                  </Badge>
                ))}
              </div>
            </div>

            <div className="space-y-2">
              <h3 className="text-sm font-medium">Suggested Training Topics</h3>
              <div className="flex flex-wrap gap-2">
                {selfEvaluation.suggestedTraining.map((item, index) => (
                  <Badge key={index} variant="outline" className="bg-blue-50">
                    {item}
                  </Badge>
                ))}
              </div>
            </div>
          </div>
        ) : (
          <div className="flex items-center justify-center h-[300px] text-center text-muted-foreground">
            <div>
              <p>No evaluation yet</p>
              <p className="text-sm">Submit a task to see Hermes' self-evaluation</p>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  )
}

