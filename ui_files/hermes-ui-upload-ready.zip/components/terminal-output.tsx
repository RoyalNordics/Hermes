"use client"

import { useHermes } from "@/context/hermes-context"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Copy } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

export default function TerminalOutput() {
  const { agentResponse, buildLog, isLoading } = useHermes()
  const { toast } = useToast()

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text)
    toast({
      title: "Copied to clipboard",
      description: "The content has been copied to your clipboard.",
    })
  }

  return (
    <Card className="border border-gray-200">
      <CardContent className="p-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Agent Response */}
          <div className="space-y-2">
            <div className="flex justify-between items-center">
              <h3 className="text-lg font-medium">Agent Response</h3>
              {agentResponse && (
                <Button variant="outline" size="sm" onClick={() => copyToClipboard(agentResponse.content)}>
                  <Copy className="h-4 w-4 mr-2" />
                  Copy
                </Button>
              )}
            </div>
            <div className="bg-black text-green-400 font-mono text-sm p-4 rounded-md h-[400px] overflow-auto">
              {isLoading ? (
                <div className="animate-pulse">
                  <span className="inline-block">Generating response</span>
                  <span className="inline-block animate-bounce">.</span>
                  <span className="inline-block animate-bounce delay-100">.</span>
                  <span className="inline-block animate-bounce delay-200">.</span>
                </div>
              ) : agentResponse ? (
                <pre className="whitespace-pre-wrap">{agentResponse.content}</pre>
              ) : (
                <span className="text-gray-500">No response yet. Submit a task to see Hermes' response.</span>
              )}
            </div>
          </div>

          {/* Build Log */}
          <div className="space-y-2">
            <div className="flex justify-between items-center">
              <h3 className="text-lg font-medium">Build Log</h3>
              {buildLog && (
                <Button variant="outline" size="sm" onClick={() => copyToClipboard(buildLog.content)}>
                  <Copy className="h-4 w-4 mr-2" />
                  Copy
                </Button>
              )}
            </div>
            <div className="bg-black text-white font-mono text-sm p-4 rounded-md h-[400px] overflow-auto">
              {isLoading ? (
                <div className="animate-pulse">
                  <span className="inline-block">Building</span>
                  <span className="inline-block animate-bounce">.</span>
                  <span className="inline-block animate-bounce delay-100">.</span>
                  <span className="inline-block animate-bounce delay-200">.</span>
                </div>
              ) : buildLog ? (
                <pre className="whitespace-pre-wrap">{buildLog.content}</pre>
              ) : (
                <span className="text-gray-500">No build log yet. Submit a task to see the build process.</span>
              )}
            </div>
          </div>
        </div>

        {/* Self-Evaluation */}
        {agentResponse && agentResponse.evaluation && (
          <div className="mt-6 p-4 bg-gray-50 rounded-md">
            <h3 className="text-lg font-medium">Self-Evaluation</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
              <div className="space-y-4">
                <div>
                  <div className="flex justify-between">
                    <span className="text-sm font-medium">Task Difficulty:</span>
                    <span className="text-sm">{agentResponse.evaluation.difficulty}/10</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2.5 mt-1">
                    <div
                      className="bg-blue-600 h-2.5 rounded-full"
                      style={{ width: `${agentResponse.evaluation.difficulty * 10}%` }}
                    ></div>
                  </div>
                </div>

                <div>
                  <div className="flex justify-between">
                    <span className="text-sm font-medium">Confidence Level:</span>
                    <span className="text-sm">{agentResponse.evaluation.confidence}/10</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2.5 mt-1">
                    <div
                      className="bg-green-600 h-2.5 rounded-full"
                      style={{ width: `${agentResponse.evaluation.confidence * 10}%` }}
                    ></div>
                  </div>
                </div>
              </div>

              <div className="space-y-4">
                <div>
                  <span className="text-sm font-medium">Missing Knowledge Areas:</span>
                  <div className="flex flex-wrap gap-2 mt-2">
                    {agentResponse.evaluation.missingKnowledge.map((item, index) => (
                      <span key={index} className="px-2 py-1 bg-red-100 text-red-800 text-xs rounded-full">
                        {item}
                      </span>
                    ))}
                  </div>
                </div>

                <div>
                  <span className="text-sm font-medium">Suggested Training Topics:</span>
                  <div className="flex flex-wrap gap-2 mt-2">
                    {agentResponse.evaluation.suggestedTraining.map((item, index) => (
                      <span key={index} className="px-2 py-1 bg-blue-100 text-blue-800 text-xs rounded-full">
                        {item}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  )
}

