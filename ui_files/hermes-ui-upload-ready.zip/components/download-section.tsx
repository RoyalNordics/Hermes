"use client"

import { useHermes } from "@/context/hermes-context"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Download } from "lucide-react"

export default function DownloadSection() {
  const { buildLog } = useHermes()

  const handleDownload = () => {
    if (!buildLog) {
      alert("No build log available. Submit a task first.")
      return
    }

    // In a real app, this would download the actual build log
    const blob = new Blob([buildLog.content], { type: "text/plain" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = "hermes-build-log.txt"
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
  }

  return (
    <Card className="border border-gray-200">
      <CardContent className="p-6">
        <div className="flex flex-col items-center">
          <h2 className="text-xl font-bold mb-2">Download section</h2>
          <p className="text-sm text-gray-500 mb-4">Build log</p>
          <Button onClick={handleDownload} disabled={!buildLog}>
            <Download className="mr-2 h-4 w-4" />
            Download
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}

