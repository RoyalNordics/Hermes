"use client"

import type React from "react"

import { useState } from "react"
import { useHermes } from "@/context/hermes-context"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Slider } from "@/components/ui/slider"

export default function ManualFeedbackSection() {
  const { submitFeedback, manualFeedback, currentTask, isLoading } = useHermes()
  const [successScore, setSuccessScore] = useState(7)
  const [notes, setNotes] = useState("")

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    submitFeedback({
      successScore,
      notes,
    })
  }

  return (
    <Card className="h-full">
      <CardHeader>
        <CardTitle>Manual Feedback</CardTitle>
        <CardDescription>Provide your assessment of Hermes' performance</CardDescription>
      </CardHeader>
      <CardContent>
        {!currentTask ? (
          <div className="flex items-center justify-center h-[300px] text-center text-muted-foreground">
            <div>
              <p>No task submitted yet</p>
              <p className="text-sm">Submit a task to provide feedback</p>
            </div>
          </div>
        ) : manualFeedback ? (
          <div className="space-y-4">
            <div>
              <h3 className="text-sm font-medium mb-2">Success Score</h3>
              <div className="flex items-center gap-2">
                <Slider value={[manualFeedback.successScore]} min={1} max={10} step={1} disabled />
                <span className="w-8 text-center">{manualFeedback.successScore}</span>
              </div>
            </div>
            <div>
              <h3 className="text-sm font-medium mb-2">Notes</h3>
              <div className="p-3 bg-gray-50 rounded-md">
                <p className="text-sm whitespace-pre-wrap">{manualFeedback.notes || "No notes provided."}</p>
              </div>
            </div>
            <div className="pt-2">
              <p className="text-sm text-muted-foreground">Feedback submitted. Thank you for your input!</p>
            </div>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <Label htmlFor="success-score">Success Score (1-10)</Label>
                <span className="text-sm">{successScore}</span>
              </div>
              <div className="flex items-center gap-2">
                <Slider
                  id="success-score"
                  value={[successScore]}
                  min={1}
                  max={10}
                  step={1}
                  onValueChange={(value) => setSuccessScore(value[0])}
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="notes">Notes / Comments</Label>
              <Textarea
                id="notes"
                placeholder="Provide feedback on Hermes' performance..."
                rows={5}
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
              />
            </div>

            <Button type="submit" className="w-full" disabled={isLoading}>
              Submit Feedback
            </Button>
          </form>
        )}
      </CardContent>
    </Card>
  )
}

