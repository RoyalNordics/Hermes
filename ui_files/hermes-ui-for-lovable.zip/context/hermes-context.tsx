"use client"

import { createContext, useContext, useState, type ReactNode } from "react"

export type TaskCategory = "frontend" | "backend" | "logic" | "integration" | "database" | "security" | "performance"

export interface TrainingData {
  category: TaskCategory
  weaknesses: string[]
  averageScore: number
  count: number
}

export interface ProjectConfig {
  name: string
  uiFiles: File | null
  featuresOverview: File | null
  projectManifest: File | null
  hermesRules: File | null
  moduleStructure: File | null
  structureMap: File | null
}

export interface Task {
  prompt: string
}

export interface AgentResponse {
  content: string
  evaluation: {
    difficulty: number
    confidence: number
    missingKnowledge: string[]
    suggestedTraining: string[]
  }
}

export interface BuildLog {
  content: string
}

export interface ManualFeedback {
  successScore: number
  notes: string
}

interface HermesContextType {
  projectConfig: ProjectConfig
  updateProjectConfig: (key: keyof ProjectConfig, value: any) => void
  currentTask: Task
  updateTask: (key: keyof Task, value: any) => void
  agentResponse: AgentResponse | null
  setAgentResponse: (response: AgentResponse | null) => void
  buildLog: BuildLog | null
  setBuildLog: (log: BuildLog | null) => void
  submitTask: () => void
  isLoading: boolean
  trainingData: TrainingData[]
  selfEvaluation: any // TODO: Define type
  manualFeedback: ManualFeedback | null
  submitFeedback: (feedback: ManualFeedback) => void
}

const defaultProjectConfig: ProjectConfig = {
  name: "",
  uiFiles: null,
  featuresOverview: null,
  projectManifest: null,
  hermesRules: null,
  moduleStructure: null,
  structureMap: null,
}

const defaultTask: Task = {
  prompt: "",
}

const HermesContext = createContext<HermesContextType | undefined>(undefined)

export const useHermes = () => {
  const context = useContext(HermesContext)
  if (!context) {
    throw new Error("useHermes must be used within a HermesProvider")
  }
  return context
}

export const HermesProvider = ({ children }: { children: ReactNode }) => {
  const [projectConfig, setProjectConfig] = useState<ProjectConfig>(defaultProjectConfig)
  const [currentTask, setCurrentTask] = useState<Task>(defaultTask)
  const [agentResponse, setAgentResponse] = useState<AgentResponse | null>(null)
  const [buildLog, setBuildLog] = useState<BuildLog | null>(null)
  const [isLoading, setIsLoading] = useState(false)
  const [trainingData, setTrainingData] = useState<TrainingData[]>([
    {
      category: "frontend",
      weaknesses: ["Accessibility", "Animation", "Responsive design", "State management", "Performance optimization"],
      averageScore: 7.2,
      count: 15,
    },
    {
      category: "backend",
      weaknesses: ["Error handling", "Authentication", "Database optimization", "API design", "Caching strategies"],
      averageScore: 6.8,
      count: 12,
    },
    {
      category: "logic",
      weaknesses: ["Algorithm optimization", "Edge cases", "Time complexity", "Space complexity", "Recursion"],
      averageScore: 8.1,
      count: 9,
    },
    {
      category: "integration",
      weaknesses: ["Error handling", "Authentication flows", "Webhook management", "API versioning", "Rate limiting"],
      averageScore: 6.5,
      count: 7,
    },
    {
      category: "database",
      weaknesses: [
        "Query optimization",
        "Schema design",
        "Indexing strategies",
        "Transaction management",
        "NoSQL modeling",
      ],
      averageScore: 7.4,
      count: 8,
    },
    {
      category: "security",
      weaknesses: ["Input validation", "Authentication", "Authorization", "CSRF protection", "XSS prevention"],
      averageScore: 6.2,
      count: 10,
    },
    {
      category: "performance",
      weaknesses: ["Caching", "Code splitting", "Lazy loading", "Memory management", "Network optimization"],
      averageScore: 7.8,
      count: 6,
    },
  ])
  const [selfEvaluation, setSelfEvaluation] = useState(null)
  const [manualFeedback, setManualFeedback] = useState<ManualFeedback | null>(null)

  const updateProjectConfig = (key: keyof ProjectConfig, value: any) => {
    setProjectConfig((prev) => ({
      ...prev,
      [key]: value,
    }))
  }

  const updateTask = (key: keyof Task, value: any) => {
    setCurrentTask((prev) => ({
      ...prev,
      [key]: value,
    }))
  }

  const submitTask = () => {
    if (!currentTask.prompt) return

    setIsLoading(true)
    setAgentResponse(null)
    setBuildLog(null)
    setSelfEvaluation(null)
    setManualFeedback(null)

    // Simulate API call
    setTimeout(() => {
      const mockResponse: AgentResponse = {
        content: generateMockResponse(),
        evaluation: {
          difficulty: Math.floor(Math.random() * 10) + 1,
          confidence: Math.floor(Math.random() * 10) + 1,
          missingKnowledge: generateMockMissingKnowledge(),
          suggestedTraining: generateMockSuggestedTraining(),
        },
      }

      setAgentResponse(mockResponse)
      setSelfEvaluation(mockResponse.evaluation)

      // Generate mock build log
      const mockBuildLog: BuildLog = {
        content: `[INFO] Starting build process for ${projectConfig.name || "Unnamed Project"}
[INFO] Analyzing task requirements
[INFO] Generating solution
[INFO] Applying Hermes rules and constraints
[INFO] Validating solution against requirements
[INFO] Solution generated successfully
[INFO] Self-evaluation complete
[INFO] Build completed in 3.42s`,
      }

      setBuildLog(mockBuildLog)
      setIsLoading(false)
    }, 3000)
  }

  const submitFeedback = (feedback: ManualFeedback) => {
    setManualFeedback(feedback)
  }

  return (
    <HermesContext.Provider
      value={{
        projectConfig,
        updateProjectConfig,
        currentTask,
        updateTask,
        agentResponse,
        setAgentResponse,
        buildLog,
        setBuildLog,
        submitTask,
        isLoading,
        trainingData,
        selfEvaluation,
        manualFeedback,
        submitFeedback,
      }}
    >
      {children}
    </HermesContext.Provider>
  )
}

// Helper functions for mock data
function generateMockResponse(): string {
  return `I've implemented a responsive React component for the user dashboard. The component includes a navigation bar, sidebar, and main content area. It's fully responsive and works on all screen sizes.

\`\`\`jsx
import React from 'react';

export function Dashboard() {
  return (
    <div className="flex h-screen bg-gray-100">
      <aside className="w-64 bg-white shadow-md">
        {/* Sidebar content */}
      </aside>
      <main className="flex-1 overflow-y-auto">
        {/* Main content */}
      </main>
    </div>
  );
}
\`\`\`

I've also included hover states and animations for interactive elements.`
}

function generateMockMissingKnowledge(): string[] {
  return ["Advanced animation techniques", "Web accessibility standards", "Server components in Next.js"]
}

function generateMockSuggestedTraining(): string[] {
  return ["Advanced React patterns", "Web Animation API", "ARIA and accessibility"]
}

