import Image from "next/image"

export default function DesignMockup() {
  return (
    <div className="bg-white p-8">
      <div className="max-w-[1200px] mx-auto border border-gray-200 rounded-lg shadow-lg p-8 bg-white">
        {/* Header with Logo */}
        <div className="flex justify-between items-start mb-8">
          <h1 className="text-3xl font-bold">Hermes Eval & Training</h1>
          <Image src="/images/hermes-logo.png" alt="Hermes Logo" width={120} height={120} className="h-36 w-auto" />
        </div>

        {/* Project Configuration and Upload Section */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
          {/* Project Configuration */}
          <div className="border border-gray-200 rounded-lg p-6 bg-white shadow-sm">
            <h2 className="text-xl font-semibold mb-4">Project Configuration</h2>
            <div className="space-y-6">
              <div className="space-y-2">
                <label className="text-sm font-medium">Project name:</label>
                <div className="h-10 border border-gray-300 rounded-md px-3 bg-gray-50"></div>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">Hermes rules</label>
                <div className="h-10 border border-gray-300 rounded-md flex items-center px-3 bg-gray-50">
                  <span className="text-gray-500 text-sm">Upload</span>
                </div>
                <div className="text-sm text-blue-600">Download template</div>
              </div>
            </div>
          </div>

          {/* Upload Section */}
          <div className="border border-gray-200 rounded-lg p-6 bg-white shadow-sm">
            <h2 className="text-xl font-semibold mb-4">Upload Section</h2>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <label className="text-sm font-medium">UI files</label>
                <div className="h-10 border border-gray-300 rounded-md flex items-center px-3 bg-gray-50">
                  <span className="text-gray-500 text-sm">Upload .zip</span>
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">Features overview</label>
                <div className="h-10 border border-gray-300 rounded-md flex items-center px-3 bg-gray-50">
                  <span className="text-gray-500 text-sm">Upload</span>
                </div>
                <div className="text-sm text-blue-600">Download template</div>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">Project manifest</label>
                <div className="h-10 border border-gray-300 rounded-md flex items-center px-3 bg-gray-50">
                  <span className="text-gray-500 text-sm">Upload</span>
                </div>
                <div className="text-sm text-blue-600">Download template</div>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">Module structure</label>
                <div className="h-10 border border-gray-300 rounded-md flex items-center px-3 bg-gray-50">
                  <span className="text-gray-500 text-sm">Upload</span>
                </div>
                <div className="text-sm text-blue-600">Download template</div>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">Structure map</label>
                <div className="h-10 border border-gray-300 rounded-md flex items-center px-3 bg-gray-50">
                  <span className="text-gray-500 text-sm">Upload</span>
                </div>
                <div className="text-sm text-blue-600">Download template</div>
              </div>
            </div>
          </div>
        </div>

        {/* Task Submission Area */}
        <div className="border border-gray-200 rounded-lg p-6 mb-8 bg-white shadow-sm">
          <div className="space-y-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Task prompt</label>
              <div className="h-40 border border-gray-300 rounded-md bg-gray-50"></div>
            </div>

            <div className="flex justify-end">
              <div className="bg-blue-600 text-white px-4 py-2 rounded-md">Send to Hermes</div>
            </div>
          </div>
        </div>

        {/* Terminal Output */}
        <div className="border border-gray-200 rounded-lg p-6 mb-8 bg-white shadow-sm">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Agent Response */}
            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <h3 className="text-lg font-medium">Agent Response</h3>
                <div className="border border-gray-300 rounded-md px-3 py-1 text-sm">Copy</div>
              </div>
              <div className="bg-black text-green-400 font-mono text-sm p-4 rounded-md h-[200px]">
                <div className="text-gray-500">No response yet. Submit a task to see Hermes' response.</div>
              </div>
            </div>

            {/* Build Log */}
            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <h3 className="text-lg font-medium">Build Log</h3>
                <div className="border border-gray-300 rounded-md px-3 py-1 text-sm">Copy</div>
              </div>
              <div className="bg-black text-white font-mono text-sm p-4 rounded-md h-[200px]">
                <div className="text-gray-500">No build log yet. Submit a task to see the build process.</div>
              </div>
            </div>
          </div>
        </div>

        {/* Training Subjects */}
        <div className="border border-gray-200 rounded-lg p-6 mb-8 bg-white shadow-sm">
          <h2 className="text-xl font-bold mb-6">Subject for further training:</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Frontend */}
            <div className="border rounded-lg p-4">
              <h3 className="text-lg font-medium mb-2">1. Frontend</h3>
              <ul className="space-y-2">
                <li className="flex items-start">
                  <span className="text-sm mr-2 ml-1">•</span>
                  <span className="text-sm">UI-komponenter</span>
                </li>
                <li className="flex items-start">
                  <span className="text-sm mr-2 ml-1">•</span>
                  <span className="text-sm">Brugeroplevelse (UX)</span>
                </li>
                <li className="flex items-start">
                  <span className="text-sm mr-2 ml-1">•</span>
                  <span className="text-sm">Styling (CSS, Tailwind, Theme)</span>
                </li>
                <li className="flex items-start">
                  <div className="text-red-500 mr-2">→</div>
                  <span className="text-sm text-red-600 font-medium">UI-states & interaktion</span>
                </li>
                <li className="flex items-start">
                  <div className="text-red-500 mr-2">→</div>
                  <span className="text-sm text-red-600 font-medium">Form management</span>
                </li>
                <li className="flex items-start">
                  <span className="text-sm mr-2 ml-1">•</span>
                  <span className="text-sm">Validering på klientsiden</span>
                </li>
              </ul>
            </div>

            {/* Backend */}
            <div className="border rounded-lg p-4">
              <h3 className="text-lg font-medium mb-2">2. Backend</h3>
              <ul className="space-y-2">
                <li className="flex items-start">
                  <span className="text-sm mr-2 ml-1">•</span>
                  <span className="text-sm">API-design (REST, GraphQL)</span>
                </li>
                <li className="flex items-start">
                  <span className="text-sm mr-2 ml-1">•</span>
                  <span className="text-sm">Forretningslogik</span>
                </li>
                <li className="flex items-start">
                  <span className="text-sm mr-2 ml-1">•</span>
                  <span className="text-sm">Database integration</span>
                </li>
                <li className="flex items-start">
                  <div className="text-red-500 mr-2">→</div>
                  <span className="text-sm text-red-600 font-medium">Authentication & Authorization</span>
                </li>
                <li className="flex items-start">
                  <div className="text-red-500 mr-2">→</div>
                  <span className="text-sm text-red-600 font-medium">Error handling og validering</span>
                </li>
                <li className="flex items-start">
                  <span className="text-sm mr-2 ml-1">•</span>
                  <span className="text-sm">Logging & Monitoring</span>
                </li>
              </ul>
            </div>

            {/* System Architecture */}
            <div className="border rounded-lg p-4">
              <h3 className="text-lg font-medium mb-2">3. Systemarkitektur</h3>
              <ul className="space-y-2">
                <li className="flex items-start">
                  <span className="text-sm mr-2 ml-1">•</span>
                  <span className="text-sm">Design patterns</span>
                </li>
                <li className="flex items-start">
                  <span className="text-sm mr-2 ml-1">•</span>
                  <span className="text-sm">Modkobling</span>
                </li>
                <li className="flex items-start">
                  <span className="text-sm mr-2 ml-1">•</span>
                  <span className="text-sm">Event-driven design</span>
                </li>
                <li className="flex items-start">
                  <span className="text-sm mr-2 ml-1">•</span>
                  <span className="text-sm">Microservices vs. monolit</span>
                </li>
                <li className="flex items-start">
                  <div className="text-red-500 mr-2">→</div>
                  <span className="text-sm text-red-600 font-medium">CI/CD (build/deploy pipelines)</span>
                </li>
              </ul>
            </div>

            {/* Integration & Communication */}
            <div className="border rounded-lg p-4">
              <h3 className="text-lg font-medium mb-2">4. Integration & Kommunikation</h3>
              <ul className="space-y-2">
                <li className="flex items-start">
                  <div className="text-red-500 mr-2">→</div>
                  <span className="text-sm text-red-600 font-medium">API-kald mellem systemer</span>
                </li>
                <li className="flex items-start">
                  <span className="text-sm mr-2 ml-1">•</span>
                  <span className="text-sm">Webhooks & callbacks</span>
                </li>
                <li className="flex items-start">
                  <div className="text-red-500 mr-2">→</div>
                  <span className="text-sm text-red-600 font-medium">3rd party services (Stripe, SendGrid, AWS)</span>
                </li>
                <li className="flex items-start">
                  <span className="text-sm mr-2 ml-1">•</span>
                  <span className="text-sm">OAuth / Tokens / SSO</span>
                </li>
              </ul>
            </div>

            {/* Data Handling */}
            <div className="border rounded-lg p-4">
              <h3 className="text-lg font-medium mb-2">5. Datahåndtering</h3>
              <ul className="space-y-2">
                <li className="flex items-start">
                  <span className="text-sm mr-2 ml-1">•</span>
                  <span className="text-sm">Databasedesign</span>
                </li>
                <li className="flex items-start">
                  <span className="text-sm mr-2 ml-1">•</span>
                  <span className="text-sm">Migrationer & seed data</span>
                </li>
                <li className="flex items-start">
                  <span className="text-sm mr-2 ml-1">•</span>
                  <span className="text-sm">Query-optimering</span>
                </li>
                <li className="flex items-start">
                  <span className="text-sm mr-2 ml-1">•</span>
                  <span className="text-sm">Caching-strategier</span>
                </li>
                <li className="flex items-start">
                  <span className="text-sm mr-2 ml-1">•</span>
                  <span className="text-sm">Datavalidering & normalisering</span>
                </li>
              </ul>
            </div>

            {/* System Understanding & Logic */}
            <div className="border rounded-lg p-4">
              <h3 className="text-lg font-medium mb-2">6. Systemforståelse & logik</h3>
              <ul className="space-y-2">
                <li className="flex items-start">
                  <div className="text-red-500 mr-2">→</div>
                  <span className="text-sm text-red-600 font-medium">Rationale bag strukturen</span>
                </li>
                <li className="flex items-start">
                  <span className="text-sm mr-2 ml-1">•</span>
                  <span className="text-sm">Domænemodel & use cases</span>
                </li>
                <li className="flex items-start">
                  <div className="text-red-500 mr-2">→</div>
                  <span className="text-sm text-red-600 font-medium">Forståelse for brugerens mål</span>
                </li>
                <li className="flex items-start">
                  <span className="text-sm mr-2 ml-1">•</span>
                  <span className="text-sm">Edge cases & konflikter</span>
                </li>
                <li className="flex items-start">
                  <span className="text-sm mr-2 ml-1">•</span>
                  <span className="text-sm">Workflow & afhængigheder</span>
                </li>
              </ul>
            </div>
          </div>
        </div>

        {/* Download Section */}
        <div className="border border-gray-200 rounded-lg p-6 bg-white shadow-sm">
          <div className="flex flex-col items-center">
            <h2 className="text-xl font-bold mb-2">Download section</h2>
            <p className="text-sm text-gray-500 mb-4">Build log</p>
            <div className="bg-blue-600 text-white px-4 py-2 rounded-md flex items-center">
              <span className="mr-2">↓</span>
              Download
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

