"use client"

import { useHermes } from "@/context/hermes-context"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts"

export default function TrainingFocusOverview() {
  const { trainingData } = useHermes()

  // Prepare data for the chart
  const chartData = trainingData.map((item) => ({
    name: item.category.charAt(0).toUpperCase() + item.category.slice(1),
    score: item.averageScore,
    count: item.count,
  }))

  return (
    <Card>
      <CardHeader>
        <CardTitle>Training Focus Overview</CardTitle>
        <CardDescription>Summary of Hermes' performance and areas for improvement</CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="weaknesses">
          <TabsList className="grid grid-cols-3 mb-6">
            <TabsTrigger value="weaknesses">Weaknesses</TabsTrigger>
            <TabsTrigger value="performance">Performance</TabsTrigger>
            <TabsTrigger value="activity">Activity</TabsTrigger>
          </TabsList>

          <TabsContent value="weaknesses" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {trainingData.map((category) => (
                <div key={category.category} className="space-y-2">
                  <h3 className="text-sm font-medium capitalize">{category.category}</h3>
                  <div className="flex flex-wrap gap-2">
                    {category.weaknesses.map((weakness, index) => (
                      <Badge key={index} variant="outline" className="bg-red-50">
                        {weakness}
                      </Badge>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="performance">
            <div className="h-[400px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={chartData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis domain={[0, 10]} />
                  <Tooltip />
                  <Bar dataKey="score" fill="#3b82f6" name="Average Score" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </TabsContent>

          <TabsContent value="activity">
            <div className="h-[400px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={chartData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis />
                  <Tooltip />
                  <Bar dataKey="count" fill="#10b981" name="Tasks Completed" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  )
}

