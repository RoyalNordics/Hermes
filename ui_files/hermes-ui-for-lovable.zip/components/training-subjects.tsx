"use client"

import { Card, CardContent } from "@/components/ui/card"
import { ArrowRight } from "lucide-react"

export default function TrainingSubjects() {
  const trainingSubjects = [
    {
      id: 1,
      title: "Frontend",
      items: [
        { text: "UI-komponenter", highlight: false },
        { text: "Brugeroplevelse (UX)", highlight: false },
        { text: "Styling (CSS, Tailwind, Theme)", highlight: false },
        { text: "UI-states & interaktion", highlight: true },
        { text: "Form management", highlight: true },
        { text: "Validering på klientsiden", highlight: false },
      ],
    },
    {
      id: 2,
      title: "Backend",
      items: [
        { text: "API-design (REST, GraphQL)", highlight: false },
        { text: "Forretningslogik", highlight: false },
        { text: "Database integration", highlight: false },
        { text: "Authentication & Authorization", highlight: true },
        { text: "Error handling og validering", highlight: true },
        { text: "Logging & Monitoring", highlight: false },
      ],
    },
    {
      id: 3,
      title: "Systemarkitektur",
      items: [
        { text: "Design patterns", highlight: false },
        { text: "Modkobling", highlight: false },
        { text: "Event-driven design", highlight: false },
        { text: "Microservices vs. monolit", highlight: false },
        { text: "CI/CD (build/deploy pipelines)", highlight: true },
      ],
    },
    {
      id: 4,
      title: "Integration & Kommunikation",
      items: [
        { text: "API-kald mellem systemer", highlight: true },
        { text: "Webhooks & callbacks", highlight: false },
        { text: "3rd party services (Stripe, SendGrid, AWS)", highlight: true },
        { text: "OAuth / Tokens / SSO", highlight: false },
      ],
    },
    {
      id: 5,
      title: "Datahåndtering",
      items: [
        { text: "Databasedesign", highlight: false },
        { text: "Migrationer & seed data", highlight: false },
        { text: "Query-optimering", highlight: false },
        { text: "Caching-strategier", highlight: false },
        { text: "Datavalidering & normalisering", highlight: false },
      ],
    },
    {
      id: 6,
      title: "Systemforståelse & logik",
      items: [
        { text: "Rationale bag strukturen", highlight: true },
        { text: "Domænemodel & use cases", highlight: false },
        { text: "Forståelse for brugerens mål", highlight: true },
        { text: "Edge cases & konflikter", highlight: false },
        { text: "Workflow & afhængigheder", highlight: false },
      ],
    },
  ]

  return (
    <Card className="border border-gray-200">
      <CardContent className="p-6">
        <h2 className="text-xl font-bold mb-6">Subject for further training:</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {trainingSubjects.map((subject) => (
            <div key={subject.id} className="border rounded-lg p-4">
              <h3 className="text-lg font-medium mb-2">
                {subject.id}. {subject.title}
              </h3>
              <ul className="space-y-2">
                {subject.items.map((item, index) => (
                  <li key={index} className="flex items-start">
                    {item.highlight ? (
                      <ArrowRight className="h-4 w-4 text-red-500 mr-2 mt-1 flex-shrink-0" />
                    ) : (
                      <span className="text-sm mr-2 ml-1">•</span>
                    )}
                    <span className={`text-sm ${item.highlight ? "text-red-600 font-medium" : ""}`}>{item.text}</span>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}

